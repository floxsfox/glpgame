extends Node
# HANYA untuk CI: godot --headless --path . -- --smoke
# Menjalankan game sebentar (menu, level, rantai, skill, alat, popup) supaya error script
# kelihatan di log GitHub Actions. Tidak aktif saat game dimainkan normal.


func _wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout


func _wait_idle(board) -> void:
	var guard := 0
	while board.busy and guard < 200:
		await get_tree().create_timer(0.1).timeout
		guard += 1


func _find_path(board) -> Array:
	var best: Array = []
	for c in board.COLS:
		for r in board.ROWS:
			var t = board.grid[c][r]
			if t == null:
				continue
			var path: Array = [t]
			var cur = t
			var moved := true
			while moved:
				moved = false
				for dx in range(-1, 2):
					for dy in range(-1, 2):
						if moved or (dx == 0 and dy == 0):
							continue
						var nc: int = cur.col + dx
						var nr: int = cur.row + dy
						if nc < 0 or nr < 0 or nc >= board.COLS or nr >= board.ROWS:
							continue
						var u = board.grid[nc][nr]
						if u != null and u.kind == t.kind and not path.has(u):
							path.append(u)
							cur = u
							moved = true
			if path.size() > best.size():
				best = path
			if best.size() >= 5:
				return best
	return best


func run() -> void:
	print("SMOKE: mulai")
	var main = Game.main
	await _wait(1.0)
	for lv in [1, 8, 12, 40, 75, 500, 20000]:
		Game.current_level = lv
		main._open("game")
		await _wait(1.8)
		var scr = main.current
		scr._close_popup()
		var board = scr.board
		await _wait_idle(board)
		for i in 5:
			var path: Array = _find_path(board)
			if path.size() >= 3 and not board.over:
				board.chain = path
				board.dragging = true
				board._release()
				await _wait(0.3)
				await _wait_idle(board)
		print("SMOKE: level ", lv, " ok | langkah=", board.moves_left, " skor=", board.score)

	# skill berantai + alat curang pada level terakhir
	var scr2 = main.current
	var b2 = scr2.board
	b2.over = false
	await _wait_idle(b2)
	b2.grid[3][3].make_special(1, 2)
	b2.grid[1][5].make_special(2, 0)
	var cells := {Vector2i(3, 3): true, Vector2i(1, 5): true}
	b2._fx_events = []
	var n: int = b2._expand_specials(cells)
	print("SMOKE: skill aktif=", n, " sel=", cells.size())
	b2.busy = true
	await b2._clear_cells(cells)
	await b2._settle()
	b2.busy = false
	b2.over = false

	# matahari ada di dalam rantai: [simbol, matahari, simbol sejenis]
	var ta = b2.grid[2][2]
	b2.grid[3][2].make_sun()
	b2.grid[4][2].set_kind(int(ta.kind))
	b2.chain = [ta, b2.grid[3][2], b2.grid[4][2]]
	b2.dragging = true
	b2.over = false
	b2.moves_left = 5
	b2._release()
	await _wait(0.4)
	await _wait_idle(b2)
	print("SMOKE: matahari dalam rantai ok")
	# matahari yang hancur oleh efek lain (target = simbol terbanyak)
	b2.grid[5][5].make_sun()
	var cells3 := {Vector2i(5, 5): true}
	b2._fx_events = []
	var n3: int = b2._expand_specials(cells3)
	print("SMOKE: matahari fallback aktif=", n3, " sel=", cells3.size())
	b2.busy = true
	await b2._clear_cells(cells3)
	await b2._settle()
	b2.busy = false
	b2.over = false

	Game.coins = 5000
	b2.request_tool("hammer")
	b2._press(b2.cell_pos(2, 2))
	await _wait(0.5)
	await _wait_idle(b2)
	b2.over = false
	b2.request_tool("swap")
	b2._press(b2.cell_pos(1, 1))
	b2._press(b2.cell_pos(4, 4))
	await _wait(0.7)
	await _wait_idle(b2)
	b2.over = false
	b2.request_tool("sun")
	b2._press(b2.cell_pos(3, 3))
	await _wait(0.5)
	await _wait_idle(b2)
	print("SMOKE: alat ok")

	scr2._close_popup()
	scr2._show_win(3, 1234, 2, 50, true)
	await _wait(1.2)
	scr2._show_lose()
	await _wait(0.6)
	scr2._close_popup()
	scr2._on_pause()
	await _wait(0.6)
	print("SMOKE: popup game ok")

	main._open("levels")
	await _wait(0.6)
	main.current._jump(999999)
	await _wait(0.4)
	main._open("menu")
	await _wait(0.8)
	var m = main.current
	m._close_popup()
	m._settings()
	await _wait(0.5)
	m._confirm_reset()
	await _wait(0.5)
	print("SMOKE: SELESAI")
	get_tree().quit()
