extends Control
# Papan permainan: sambung simbol, skill (garis/bom/hancurkan), es, alat curang.

signal state_changed
signal level_won
signal level_lost
signal toast(msg)
signal chain_changed(n)
signal tool_mode_changed(mode)

const UI = preload("res://scripts/ui.gd")
const TileScript = preload("res://scripts/tile.gd")
const COLS := 7
const ROWS := 8
const CELL := 96.0
const KIND_COLORS := [
	Color("ff4d5e"), Color("4da6ff"), Color("4de07a"), Color("ffd23f"),
	Color("c06bff"), Color("ff9a3c"), Color("ff7ac8"),
]
const LINE_AT := 5   # sambungan >= 5 -> Garis
const BOMB_AT := 6   # sambungan >= 6 -> Bom 3x3
const SUN_AT := 7    # sambungan >= 7 -> Matahari (netral, hancurkan simbol sejenis)
const SUN := 3       # kode special untuk matahari
const PRICES := {"hammer": 120, "swap": 80, "sun": 300}

var data: Dictionary = {}
var grid: Array = []
var ice: Array = []
var ice_nodes: Array = []
var chain: Array = []
var busy: bool = false
var dragging: bool = false
var over: bool = false
var moves_left: int = 0
var score: int = 0
var goals: Array = []
var sym_count: int = 4
var rng := RandomNumberGenerator.new()
var tool_mode: String = ""
var swap_first = null
var cell_layer: Node2D
var tile_layer: Node2D
var ice_layer: Node2D
var fx_layer: Node2D
var line: Line2D
var _fx_events: Array = []
var _home: Vector2 = Vector2.ZERO
var _shake_tw: Tween = null


func _ready() -> void:
	size = Vector2(COLS * CELL, ROWS * CELL)
	custom_minimum_size = size
	clip_contents = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	gui_input.connect(_on_gui_input)
	cell_layer = Node2D.new()
	tile_layer = Node2D.new()
	ice_layer = Node2D.new()
	ice_layer.z_index = 2
	fx_layer = Node2D.new()
	add_child(cell_layer)
	add_child(tile_layer)
	add_child(ice_layer)
	line = Line2D.new()
	line.width = 16.0
	line.z_index = 10
	line.begin_cap_mode = Line2D.LINE_CAP_ROUND
	line.end_cap_mode = Line2D.LINE_CAP_ROUND
	line.joint_mode = Line2D.LINE_JOINT_ROUND
	add_child(line)
	fx_layer.z_index = 20
	add_child(fx_layer)


# ------------------------------------------------------------ setup
func cell_pos(c: int, r: int) -> Vector2:
	return Vector2(float(c) * CELL + CELL * 0.5, float(r) * CELL + CELL * 0.5)


func in_bounds(q: Vector2i) -> bool:
	return q.x >= 0 and q.y >= 0 and q.x < COLS and q.y < ROWS


func start(level_data: Dictionary) -> void:
	data = level_data
	_home = position
	sym_count = int(data["symbols"])
	moves_left = int(data["moves"])
	score = 0
	over = false
	busy = true
	rng.randomize()
	goals = []
	for g in data["goals"]:
		var gd: Dictionary = g.duplicate()
		gd["have"] = 0
		goals.append(gd)
	for n in cell_layer.get_children():
		n.queue_free()
	for n in ice_layer.get_children():
		n.queue_free()
	for n in tile_layer.get_children():
		n.queue_free()
	for c in COLS:
		for r in ROWS:
			var s := Sprite2D.new()
			s.texture = UI.tex("cell")
			s.position = cell_pos(c, r)
			cell_layer.add_child(s)
	ice = []
	ice_nodes = []
	for c in COLS:
		var ic: Array = []
		var inn: Array = []
		for r in ROWS:
			ic.append(0)
			inn.append(null)
		ice.append(ic)
		ice_nodes.append(inn)
	for e in data["ice"]:
		var c: int = int(e[0])
		var r: int = int(e[1])
		ice[c][r] = int(e[2])
		var sp := Sprite2D.new()
		sp.texture = UI.tex("ice_%d" % clampi(int(e[2]), 1, 2))
		sp.position = cell_pos(c, r)
		ice_layer.add_child(sp)
		ice_nodes[c][r] = sp
	_fill_board()
	state_changed.emit()
	var itw := create_tween()
	itw.tween_interval(1.0)
	itw.tween_callback(_end_intro)


func _end_intro() -> void:
	busy = false


func _fill_board() -> void:
	var m: Array = []
	for attempt in 40:
		m = []
		for c in COLS:
			var col: Array = []
			for r in ROWS:
				col.append(rng.randi() % sym_count)
			m.append(col)
		if _matrix_has_move(m):
			break
	grid = []
	for c in COLS:
		var col2: Array = []
		for r in ROWS:
			var t = _new_tile(c, r, int(m[c][r]))
			t.position = cell_pos(c, r - ROWS - 1)
			var tw = t.create_tween()
			tw.tween_interval(float(c) * 0.04 + float(ROWS - r) * 0.03)
			tw.tween_property(t, "position", cell_pos(c, r), 0.45).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
			col2.append(t)
		grid.append(col2)


func _new_tile(c: int, r: int, k: int) -> Node2D:
	var t = TileScript.new()
	t.setup(k, CELL * 0.86)
	t.col = c
	t.row = r
	t.position = cell_pos(c, r)
	t.z_index = 1
	tile_layer.add_child(t)
	return t


# ------------------------------------------------------------ input
func _on_gui_input(event: InputEvent) -> void:
	var mb := event as InputEventMouseButton
	if mb != null:
		if mb.button_index != MOUSE_BUTTON_LEFT:
			return
		if mb.pressed:
			_press(mb.position)
		else:
			_release()
		return
	var mm := event as InputEventMouseMotion
	if mm != null and dragging:
		_drag(mm.position)


func cell_at(p: Vector2, strict: bool) -> Vector2i:
	var c := int(floor(p.x / CELL))
	var r := int(floor(p.y / CELL))
	if c < 0 or r < 0 or c >= COLS or r >= ROWS:
		return Vector2i(-1, -1)
	if strict and p.distance_to(cell_pos(c, r)) > CELL * 0.44:
		return Vector2i(-1, -1)
	return Vector2i(c, r)


func _press(p: Vector2) -> void:
	if over or busy:
		return
	if tool_mode == "hammer":
		var hc := cell_at(p, false)
		if hc.x >= 0:
			_do_hammer(hc)
		return
	if tool_mode == "sun":
		var uc := cell_at(p, false)
		if uc.x >= 0:
			_do_sun(uc)
		return
	if tool_mode == "swap":
		var sc := cell_at(p, false)
		if sc.x >= 0:
			_swap_pick(sc)
		return
	if moves_left <= 0:
		return
	var cell := cell_at(p, true)
	if cell.x < 0:
		return
	var t = grid[cell.x][cell.y]
	if t == null:
		return
	dragging = true
	chain = [t]
	_refresh_chain()


# Jenis rantai = jenis simbol non-matahari pertama (matahari netral). -1 jika belum ada.
func _chain_kind(arr: Array) -> int:
	for t in arr:
		if t.special != SUN:
			return int(t.kind)
	return -1


func _drag(p: Vector2) -> void:
	if chain.is_empty():
		return
	var cell := cell_at(p, true)
	if cell.x < 0:
		return
	var t = grid[cell.x][cell.y]
	if t == null:
		return
	var last = chain[chain.size() - 1]
	if t == last:
		return
	if chain.size() >= 2 and t == chain[chain.size() - 2]:
		chain.pop_back()
		last.set_selected(false)
		_refresh_chain()
		return
	if chain.has(t):
		return
	var ck := _chain_kind(chain)
	if t.special != SUN and ck >= 0 and t.kind != ck:
		return
	if absi(t.col - last.col) > 1 or absi(t.row - last.row) > 1:
		return
	chain.append(t)
	_refresh_chain()
	Sound.sfx("tick", minf(2.2, 1.0 + 0.07 * float(chain.size() - 1)))


func _refresh_chain() -> void:
	line.clear_points()
	for t in chain:
		t.set_selected(true)
		line.add_point(t.position)
	if not chain.is_empty():
		var ck := _chain_kind(chain)
		var col := Color(1.0, 0.9, 0.5)
		if ck >= 0:
			col = KIND_COLORS[ck % KIND_COLORS.size()]
		line.default_color = col.lightened(0.45)
	chain_changed.emit(chain.size())


func _release() -> void:
	if not dragging:
		return
	dragging = false
	if chain.size() >= 3 and not over and not busy:
		_resolve_chain()
	else:
		for t in chain:
			t.set_selected(false)
		chain = []
		line.clear_points()
		chain_changed.emit(0)


# ------------------------------------------------------------ aturan inti
func _line_cells(p: Vector2i, d: int) -> Array:
	var dv := Vector2i(0, 1)
	match d:
		0:
			dv = Vector2i(0, 1)
		1:
			dv = Vector2i(1, 0)
		2:
			dv = Vector2i(1, 1)
		3:
			dv = Vector2i(1, -1)
	var out: Array = []
	for sgn in [1, -1]:
		var q := p
		while in_bounds(q):
			out.append(q)
			q += dv * sgn
	return out


# Perluas sel yang akan dihancurkan dengan efek skill (berantai). Mengembalikan jumlah skill aktif.
# Perluas sel yang akan hancur dengan efek skill (berantai).
# ckind = jenis rantai (untuk matahari yang ada di dalam rantai), chain_cells = sel rantai.
# Mengembalikan jumlah skill yang aktif.
func _expand_specials(cells: Dictionary, ckind: int = -1, chain_cells: Dictionary = {}) -> int:
	var processed := {}
	var count := 0
	var changed := true
	while changed:
		changed = false
		for key in cells.keys():
			if processed.has(key):
				continue
			processed[key] = true
			var t = grid[key.x][key.y]
			if t == null or t.special == 0:
				continue
			count += 1
			changed = true
			if t.special == 1:
				_fx_events.append({"type": 1, "pos": key, "dir": t.dir})
				for q in _line_cells(key, t.dir):
					cells[q] = true
			elif t.special == 2:
				_fx_events.append({"type": 2, "pos": key, "dir": 0})
				for ox in range(-1, 2):
					for oy in range(-1, 2):
						var q2 := Vector2i(key.x + ox, key.y + oy)
						if in_bounds(q2):
							cells[q2] = true
			else:
				var target := -1
				if chain_cells.has(key):
					target = ckind
				if target < 0:
					target = _fallback_kind(cells)
				var targets: Array = []
				if target >= 0:
					for c in COLS:
						for r in ROWS:
							var u = grid[c][r]
							if u != null and u.special != SUN and u.kind == target:
								var k2 := Vector2i(c, r)
								targets.append(k2)
								cells[k2] = true
				_fx_events.append({"type": 4, "pos": key, "targets": targets})
	return count


# Jenis simbol paling banyak di papan (di luar sel yang sudah akan hancur).
func _fallback_kind(cells: Dictionary) -> int:
	var counts := {}
	for c in COLS:
		for r in ROWS:
			var t = grid[c][r]
			if t != null and t.special != SUN and not cells.has(Vector2i(c, r)):
				counts[t.kind] = int(counts.get(t.kind, 0)) + 1
	var best := -1
	var best_n := 0
	for k in counts.keys():
		if int(counts[k]) > best_n:
			best_n = int(counts[k])
			best = int(k)
	return best


func _resolve_chain() -> void:
	busy = true
	var ch: Array = chain.duplicate()
	for t in ch:
		t.set_selected(false)
	chain = []
	line.clear_points()
	chain_changed.emit(0)
	var n: int = ch.size()
	var ckind := _chain_kind(ch)
	var last = ch[n - 1]
	var prev = ch[n - 2]
	var dx: int = last.col - prev.col
	var dy: int = last.row - prev.row
	var d := 3
	if dx == 0:
		d = 0
	elif dy == 0:
		d = 1
	elif dx == dy:
		d = 2
	moves_left -= 1

	var cells := {}
	var chain_cells := {}
	for t in ch:
		var ck := Vector2i(t.col, t.row)
		cells[ck] = true
		chain_cells[ck] = true
	_fx_events = []
	var triggered := _expand_specials(cells, ckind, chain_cells)

	var new_special := 0
	var banner := ""
	if n >= SUN_AT:
		new_special = SUN
		banner = "MATAHARI!"
	elif n >= BOMB_AT:
		new_special = 2
		banner = "BOM!"
	elif n >= LINE_AT:
		new_special = 1
		banner = "GARIS!"
	var survivor = null
	if new_special > 0:
		for i in range(n - 1, -1, -1):
			if ch[i].special == 0:
				survivor = ch[i]
				break
		if survivor == null:
			new_special = 0
			banner = ""
	var extra := maxi(0, cells.size() - n)
	if survivor != null:
		cells.erase(Vector2i(survivor.col, survivor.row))
	var gained := int(float(n) * 10.0 * (1.0 + float(n - 3) * 0.5)) + extra * 10 + triggered * 50
	score += gained
	_apply_goals(cells, n, triggered)
	state_changed.emit()
	_popup_text(last.position, "+%d" % gained, Color(1, 0.95, 0.5))
	if banner != "":
		_popup_text(Vector2(size.x / 2.0, size.y / 2.0 - 40.0), banner, Color(1, 0.7, 0.3), 60)
	if triggered == 0:
		Sound.sfx("pop", 1.0 + minf(float(n), 10.0) * 0.03)
	await _clear_cells(cells)
	if not is_inside_tree():
		return
	if survivor != null:
		if new_special == SUN:
			survivor.make_sun()
		else:
			survivor.make_special(new_special, d)
		Sound.sfx("special")
	await _settle()
	busy = false


func _apply_goals(cells: Dictionary, n_chain: int, triggered: int) -> void:
	var collected := {}
	var ice_removed := 0
	for key in cells.keys():
		var t = grid[key.x][key.y]
		if t != null:
			collected[t.kind] = int(collected.get(t.kind, 0)) + 1
		if int(ice[key.x][key.y]) > 0:
			ice[key.x][key.y] = int(ice[key.x][key.y]) - 1
			ice_removed += 1
			_update_ice_node(key.x, key.y)
	for g in goals:
		match str(g["type"]):
			"collect":
				g["have"] = int(g["have"]) + int(collected.get(int(g["kind"]), 0))
			"ice":
				g["have"] = int(g["have"]) + ice_removed
			"chain":
				if n_chain >= int(g["len"]):
					g["have"] = int(g["have"]) + 1
			"special":
				g["have"] = int(g["have"]) + triggered


func _update_ice_node(c: int, r: int) -> void:
	var node = ice_nodes[c][r]
	if node == null:
		return
	var v: int = int(ice[c][r])
	if v <= 0:
		ice_nodes[c][r] = null
		var tw = node.create_tween()
		tw.set_parallel(true)
		tw.tween_property(node, "scale", Vector2(1.5, 1.5), 0.25)
		tw.tween_property(node, "modulate:a", 0.0, 0.25)
		tw.chain().tween_callback(node.queue_free)
		_burst(cell_pos(c, r), 1)
	else:
		node.texture = UI.tex("ice_%d" % clampi(v, 1, 2))


func _clear_cells(cells: Dictionary) -> void:
	var has_sun := false
	for ev in _fx_events:
		_play_fx(ev)
		if int(ev["type"]) == 4:
			has_sun = true
	if has_sun:
		await get_tree().create_timer(0.32).timeout
		if not is_inside_tree():
			return
	for key in cells.keys():
		var t = grid[key.x][key.y]
		if t == null:
			continue
		grid[key.x][key.y] = null
		_pop_tile(t)
	await get_tree().create_timer(0.3).timeout


func _pop_tile(t) -> void:
	var tw = t.create_tween()
	tw.set_parallel(true)
	tw.tween_property(t, "scale", Vector2(1.5, 1.5), 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(t, "modulate:a", 0.0, 0.22)
	tw.chain().tween_callback(t.queue_free)
	_burst(t.position, int(t.kind))


func _burst(pos: Vector2, k: int) -> void:
	var p := CPUParticles2D.new()
	p.position = pos
	p.amount = 7
	p.lifetime = 0.55
	p.one_shot = true
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.gravity = Vector2(0, 420)
	p.initial_velocity_min = 90.0
	p.initial_velocity_max = 230.0
	p.scale_amount_min = 0.35
	p.scale_amount_max = 0.8
	p.texture = UI.tex("spark")
	p.color = Color(1.0, 0.85, 0.3) if k < 0 else KIND_COLORS[k % KIND_COLORS.size()]
	fx_layer.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func _beam(pos: Vector2, ang: float, color: Color) -> void:
	var s := Sprite2D.new()
	s.texture = UI.tex("glow")
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	s.material = mat
	s.position = pos
	s.rotation = ang
	s.modulate = color
	s.scale = Vector2(11.0, 0.55)
	fx_layer.add_child(s)
	var tw := s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "scale:y", 0.05, 0.4)
	tw.tween_property(s, "modulate:a", 0.0, 0.4)
	tw.chain().tween_callback(s.queue_free)


func _flash(pos: Vector2, from_scale: float, to_scale: float, color: Color, dur: float) -> void:
	var s := Sprite2D.new()
	s.texture = UI.tex("glow")
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	s.material = mat
	s.position = pos
	s.modulate = color
	s.scale = Vector2(from_scale, from_scale)
	fx_layer.add_child(s)
	var tw := s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "scale", Vector2(to_scale, to_scale), dur)
	tw.tween_property(s, "modulate:a", 0.0, dur)
	tw.chain().tween_callback(s.queue_free)


func _rays(pos: Vector2, from_scale: float, to_scale: float, dur: float) -> void:
	var s := Sprite2D.new()
	s.texture = UI.tex("sun_rays")
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	s.material = mat
	s.position = pos
	s.scale = Vector2(from_scale, from_scale)
	fx_layer.add_child(s)
	var tw := s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "scale", Vector2(to_scale, to_scale), dur)
	tw.tween_property(s, "rotation", 1.2, dur)
	tw.tween_property(s, "modulate:a", 0.0, dur)
	tw.chain().tween_callback(s.queue_free)


func _sun_beam(a: Vector2, b: Vector2) -> void:
	var l := Line2D.new()
	l.width = 16.0
	l.default_color = Color(1.0, 0.92, 0.55, 1.0)
	l.begin_cap_mode = Line2D.LINE_CAP_ROUND
	l.end_cap_mode = Line2D.LINE_CAP_ROUND
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	l.material = mat
	l.add_point(a)
	l.add_point(b)
	fx_layer.add_child(l)
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "width", 2.0, 0.45)
	tw.tween_property(l, "modulate:a", 0.0, 0.45)
	tw.chain().tween_callback(l.queue_free)


func _play_fx(ev: Dictionary) -> void:
	var key: Vector2i = ev["pos"]
	var p := cell_pos(key.x, key.y)
	match int(ev["type"]):
		1:
			Sound.sfx("slash")
			var ang := 0.0
			match int(ev["dir"]):
				0:
					ang = PI / 2.0
				1:
					ang = 0.0
				2:
					ang = PI / 4.0
				3:
					ang = -PI / 4.0
			_beam(p, ang, Color(1.0, 0.95, 0.6, 0.95))
		2:
			Sound.sfx("boom")
			_flash(p, 0.5, 3.4, Color(1.0, 0.55, 0.2, 0.95), 0.4)
			shake(7.0)
		4:
			Sound.sfx("sun")
			_flash(p, 0.6, 5.5, Color(1.0, 0.85, 0.35, 1.0), 0.6)
			_rays(p, 0.4, 3.4, 0.7)
			for tk in ev["targets"]:
				var tp := cell_pos(tk.x, tk.y)
				_sun_beam(p, tp)
				_flash(tp, 0.3, 1.8, Color(1.0, 0.9, 0.5, 0.95), 0.45)
			_popup_text(p, "SINAR MATAHARI!", Color(1.0, 0.9, 0.4), 40)
			shake(9.0)


func _popup_text(pos: Vector2, text: String, color: Color, font_size: int = 40) -> void:
	var l := UI.label(text, font_size, color, 8)
	l.size = Vector2(420, 70)
	l.position = pos - Vector2(210, 35)
	fx_layer.add_child(l)
	var tw := l.create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y - 70.0, 0.9)
	tw.tween_property(l, "modulate:a", 0.0, 0.9).set_delay(0.35)
	tw.chain().tween_callback(l.queue_free)


func shake(strength: float = 10.0) -> void:
	if _shake_tw != null:
		_shake_tw.kill()
	_shake_tw = create_tween()
	for i in 6:
		_shake_tw.tween_property(self, "position", _home + Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * strength, 0.03)
	_shake_tw.tween_property(self, "position", _home, 0.03)


# ------------------------------------------------------------ gravitasi & acak
func _drop(t, target: Vector2, dist: int) -> float:
	var dur := 0.22 + 0.07 * float(dist)
	var tw = t.create_tween()
	tw.tween_property(t, "position", target, dur).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	return dur


func _gravity() -> float:
	var longest := 0.0
	for c in COLS:
		var stack: Array = []
		for r in range(ROWS - 1, -1, -1):
			if grid[c][r] != null:
				stack.append(grid[c][r])
		var missing: int = ROWS - stack.size()
		for r in ROWS:
			grid[c][r] = null
		for i in stack.size():
			var t = stack[i]
			var nr: int = ROWS - 1 - i
			grid[c][nr] = t
			if t.row != nr:
				var dist: int = nr - t.row
				t.row = nr
				longest = maxf(longest, _drop(t, cell_pos(c, nr), dist))
		for j in missing:
			var t2 = _new_tile(c, j, rng.randi() % sym_count)
			t2.position = cell_pos(c, j - missing)
			grid[c][j] = t2
			longest = maxf(longest, _drop(t2, cell_pos(c, j), missing))
	return longest


func _settle() -> void:
	var dur := _gravity()
	await get_tree().create_timer(dur + 0.08).timeout
	if not is_inside_tree():
		return
	if not _has_move():
		await _reshuffle()
		if not is_inside_tree():
			return
	state_changed.emit()
	_check_end()


func _kinds_matrix() -> Array:
	var m: Array = []
	for c in COLS:
		var col: Array = []
		for r in ROWS:
			var t = grid[c][r]
			if t == null:
				col.append(-1)
			elif t.special == SUN:
				col.append(-2)
			else:
				col.append(int(t.kind))
		m.append(col)
	return m


func _has_move() -> bool:
	return _matrix_has_move(_kinds_matrix())


# -1 = kosong, -2 = matahari (netral, cocok dengan jenis apa pun)
func _matrix_has_move(m: Array) -> bool:
	for k in sym_count:
		var seen := {}
		for c in COLS:
			for r in ROWS:
				var v: int = int(m[c][r])
				if (v != k and v != -2) or seen.has(Vector2i(c, r)):
					continue
				var count := 0
				var stack: Array = [Vector2i(c, r)]
				seen[Vector2i(c, r)] = true
				while stack.size() > 0:
					var p: Vector2i = stack.pop_back()
					count += 1
					for dx in range(-1, 2):
						for dy in range(-1, 2):
							if dx == 0 and dy == 0:
								continue
							var q := Vector2i(p.x + dx, p.y + dy)
							if not in_bounds(q) or seen.has(q):
								continue
							var v2: int = int(m[q.x][q.y])
							if v2 == k or v2 == -2:
								seen[q] = true
								stack.append(q)
				if count >= 3:
					return true
	return false


func _reshuffle() -> void:
	toast.emit("Tidak ada langkah - diacak!")
	Sound.sfx("shuffle")
	var tiles: Array = []
	for c in COLS:
		for r in ROWS:
			if grid[c][r] != null:
				tiles.append(grid[c][r])
	for attempt in 60:
		for t in tiles:
			if t.special != SUN:
				t.set_kind(rng.randi() % sym_count)
		if _has_move():
			break
	for t in tiles:
		var tw = t.create_tween()
		tw.tween_property(t, "scale", Vector2(0.7, 0.7), 0.12)
		tw.tween_property(t, "scale", Vector2.ONE, 0.12)
	await get_tree().create_timer(0.3).timeout


# ------------------------------------------------------------ menang / kalah
func goals_done() -> bool:
	for g in goals:
		if int(g["have"]) < int(g["need"]):
			return false
	return true


func _check_end() -> void:
	if over:
		return
	if goals_done():
		over = true
		level_won.emit()
	elif moves_left <= 0:
		over = true
		level_lost.emit()


func add_moves(n: int) -> void:
	moves_left += n
	over = false
	busy = false
	state_changed.emit()


# ------------------------------------------------------------ alat curang (pakai koin)
func _set_tool_mode(mode: String) -> void:
	if swap_first != null:
		swap_first.set_selected(false)
		swap_first = null
	tool_mode = mode
	tool_mode_changed.emit(mode)


func request_tool(tool_name: String) -> void:
	if busy or over:
		return
	if tool_mode == tool_name:
		_set_tool_mode("")
		return
	var price: int = int(PRICES[tool_name])
	if Game.coins < price:
		Sound.sfx("error")
		toast.emit("Koin kurang! Butuh %d koin" % price)
		return
	_set_tool_mode(tool_name)


# Alat "Matahari": ubah 1 simbol pilihan menjadi matahari (tidak perlu menyambung 7).
func _do_sun(cell: Vector2i) -> void:
	var t = grid[cell.x][cell.y]
	if t == null:
		return
	if t.special == SUN:
		toast.emit("Itu sudah matahari")
		return
	if not Game.spend_coins(int(PRICES["sun"])):
		Sound.sfx("error")
		toast.emit("Koin kurang!")
		_set_tool_mode("")
		return
	_set_tool_mode("")
	t.make_sun()
	Sound.sfx("special")
	var p := cell_pos(cell.x, cell.y)
	_flash(p, 0.4, 2.6, Color(1.0, 0.85, 0.3, 0.95), 0.4)
	_rays(p, 0.3, 1.8, 0.5)
	_popup_text(p, "MATAHARI!", Color(1, 0.85, 0.3), 44)
	state_changed.emit()





func _do_hammer(cell: Vector2i) -> void:
	if grid[cell.x][cell.y] == null:
		return
	if not Game.spend_coins(int(PRICES["hammer"])):
		Sound.sfx("error")
		toast.emit("Koin kurang!")
		_set_tool_mode("")
		return
	_set_tool_mode("")
	busy = true
	Sound.sfx("hammer")
	var cells := {}
	cells[cell] = true
	for off in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		var q: Vector2i = cell + off
		if in_bounds(q):
			cells[q] = true
	_fx_events = []
	var trig := _expand_specials(cells)
	score += cells.size() * 10 + trig * 50
	_apply_goals(cells, 0, trig)
	state_changed.emit()
	_flash(cell_pos(cell.x, cell.y), 0.4, 2.4, Color(1.0, 0.85, 0.3, 0.95), 0.35)
	shake(9.0)
	_popup_text(cell_pos(cell.x, cell.y), "PALU DEWA!", Color(1, 0.85, 0.3), 44)
	await _clear_cells(cells)
	if not is_inside_tree():
		return
	await _settle()
	busy = false


func _swap_pick(cell: Vector2i) -> void:
	var t = grid[cell.x][cell.y]
	if t == null:
		return
	if swap_first == null:
		swap_first = t
		t.set_selected(true)
		Sound.sfx("tick")
		toast.emit("Pilih simbol kedua untuk ditukar")
		return
	if t == swap_first:
		t.set_selected(false)
		swap_first = null
		return
	if not Game.spend_coins(int(PRICES["swap"])):
		Sound.sfx("error")
		toast.emit("Koin kurang!")
		_set_tool_mode("")
		return
	var a = swap_first
	swap_first = null
	a.set_selected(false)
	_set_tool_mode("")
	_swap_tiles(a, t)


func _swap_tiles(a, b) -> void:
	busy = true
	Sound.sfx("swap")
	var ac: int = a.col
	var ar: int = a.row
	grid[a.col][a.row] = b
	grid[b.col][b.row] = a
	a.col = b.col
	a.row = b.row
	b.col = ac
	b.row = ar
	var tw1 = a.create_tween()
	tw1.tween_property(a, "position", cell_pos(a.col, a.row), 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	var tw2 = b.create_tween()
	tw2.tween_property(b, "position", cell_pos(b.col, b.row), 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	await get_tree().create_timer(0.34).timeout
	if not is_inside_tree():
		return
	if not _has_move():
		await _reshuffle()
	state_changed.emit()
	busy = false
