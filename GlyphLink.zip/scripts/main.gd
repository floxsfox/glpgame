extends Control
# Root: mengganti layar (menu / pilih level / game) dengan transisi fade.

var current: Control = null
var fade: ColorRect
var _switching := false


func _ready() -> void:
	Game.main = self
	fade = ColorRect.new()
	fade.color = Color(0.03, 0.01, 0.1, 1)
	fade.modulate.a = 0.0
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fade)
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_open("menu")
	if OS.get_cmdline_user_args().has("--smoke"):
		var st = load("res://scripts/smoke_test.gd").new()
		add_child(st)
		st.run()


func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton or event is InputEventScreenTouch or event is InputEventKey:
		if not Sound.unlocked:
			Sound.unlocked = true
			Sound.ensure_playing()


func _open(screen_name: String) -> void:
	var paths := {
		"menu": "res://scripts/menu_screen.gd",
		"levels": "res://scripts/level_select.gd",
		"game": "res://scripts/game_screen.gd",
	}
	if current != null:
		remove_child(current)
		current.queue_free()
		current = null
	var scr = load(paths[screen_name]).new()
	add_child(scr)
	move_child(fade, get_child_count() - 1)
	current = scr


func show_screen(screen_name: String) -> void:
	if _switching:
		return
	_switching = true
	fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(fade, "modulate:a", 1.0, 0.18)
	await tw.finished
	_open(screen_name)
	var tw2 := create_tween()
	tw2.tween_property(fade, "modulate:a", 0.0, 0.22)
	await tw2.finished
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_switching = false
