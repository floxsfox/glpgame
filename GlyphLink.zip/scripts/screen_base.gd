extends Control
# Dasar semua layar: background layar penuh + "content" 720x1280 di tengah.

const UI = preload("res://scripts/ui.gd")
const DESIGN := Vector2(720, 1280)

var bg: TextureRect
var content: Control
var coin_label: Label = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_PASS
	bg = TextureRect.new()
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	content = Control.new()
	content.size = DESIGN
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(content)
	resized.connect(_relayout)
	_relayout()
	build()


func _relayout() -> void:
	if content != null:
		content.position = ((size - DESIGN) * 0.5).floor()


func build() -> void:
	pass


func coin_pill(pos: Vector2, pill_w: float = 210.0) -> Label:
	content.add_child(UI.panel(pos, Vector2(pill_w, 60), "bar_bg", 22))
	var l := UI.label(UI.fmt(Game.coins), 30, Color(1, 0.95, 0.6), 5)
	l.position = pos + Vector2(54, 0)
	l.size = Vector2(pill_w - 66, 60)
	content.add_child(l)
	content.add_child(UI.tex_rect("coin", pos + Vector2(-14, -8), Vector2(76, 76)))
	coin_label = l
	if not Game.coins_changed.is_connected(_on_coins_changed):
		Game.coins_changed.connect(_on_coins_changed)
	return l


func _on_coins_changed() -> void:
	if is_instance_valid(coin_label):
		coin_label.text = UI.fmt(Game.coins)


func _exit_tree() -> void:
	if Game.coins_changed.is_connected(_on_coins_changed):
		Game.coins_changed.disconnect(_on_coins_changed)
