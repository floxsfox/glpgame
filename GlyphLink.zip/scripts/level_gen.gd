extends RefCounted
# Generator level deterministik: level yang sama selalu menghasilkan level yang sama.
# Mendukung 1 - 1.000.000 level. Makin besar level => makin sulit.

const MAX_LEVEL := 1000000
const COLS := 7
const ROWS := 8
const THEMES := 8

const TIER_NAMES := ["Mudah", "Sedang", "Sulit", "Ahli", "Master", "Legenda"]
const TIER_COLORS := [
	Color(0.55, 1.0, 0.6), Color(0.6, 0.9, 1.0), Color(1.0, 0.9, 0.45),
	Color(1.0, 0.65, 0.35), Color(1.0, 0.45, 0.55), Color(0.85, 0.55, 1.0),
]
const TIPS := [
	"Sambung 5+ simbol untuk membuat GARIS. Sambung lagi dengan simbol sama untuk meledakkannya!",
	"Arah gesekan terakhir menentukan arah garis: atas/bawah, kiri/kanan, atau diagonal.",
	"Sambung 7+ simbol untuk membuat BOM kecil (area 3x3).",
	"Sambung 8+ simbol = HANCURKAN semua simbol di papan!",
	"Skill bisa saling menyambung: ledakan memicu skill lain di jalurnya.",
	"Sisa langkah memberi bonus skor dan koin. Hemat langkahmu!",
	"Es pecah saat simbol di atasnya dihancurkan. Garis & bom sangat membantu.",
	"Gunakan Palu Dewa untuk menembus situasi sulit (butuh koin).",
]


static func base_difficulty(level: int) -> float:
	return 1.0 - exp(-float(level) / 350.0)


static func theme_of(level: int) -> int:
	return floori(float(level - 1) / 5.0) % THEMES


static func hue_of(level: int) -> float:
	var cyc := floori(float(level - 1) / 40.0)
	return fmod(float(cyc) * 0.137, 1.0)


static func tier_name(t: int) -> String:
	return TIER_NAMES[clampi(t, 0, 5)]


static func tier_color(t: int) -> Color:
	return TIER_COLORS[clampi(t, 0, 5)]


static func hint(level: int) -> String:
	match level:
		1:
			return "Geser jari untuk menyambung 3+ simbol sejenis yang bersebelahan (diagonal juga boleh)."
		2:
			return "Sambung 5+ simbol untuk membuat GARIS. Sambung lagi dengan simbol sama untuk mengaktifkannya!"
		3:
			return "7+ simbol = BOM kecil. 8+ simbol = HANCURKAN semua simbol!"
		4:
			return "Koin bisa dipakai membeli Palu Dewa, Tukar, dan Hancurkan di bawah papan."
	return TIPS[level % TIPS.size()]


static func goal_text(g: Dictionary) -> String:
	match str(g["type"]):
		"collect":
			return "Kumpulkan %d" % int(g["need"])
		"ice":
			return "Pecahkan es x%d" % int(g["need"])
		"chain":
			return "Rantai %d+ simbol x%d" % [int(g["len"]), int(g["need"])]
		"special":
			return "Aktifkan skill x%d" % int(g["need"])
	return ""


static func goal_icon(g: Dictionary) -> String:
	match str(g["type"]):
		"collect":
			return "sym_%d" % int(g["kind"])
		"ice":
			return "goal_ice"
		"chain":
			return "goal_chain"
		"special":
			return "goal_special"
	return "star_on"


static func _shuffle(arr: Array, rng: RandomNumberGenerator) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp


static func generate(level: int) -> Dictionary:
	level = clampi(level, 1, MAX_LEVEL)
	var rng := RandomNumberGenerator.new()
	rng.seed = (level * 2654435761 + 40503) % 2147483647 + 17

	var d := base_difficulty(level)
	var boss := (level % 10 == 0)
	var mega := (level % 50 == 0)
	if level > 60:
		d = clampf(d + rng.randf_range(-0.14, 0.06), 0.0, 1.0)
	if boss:
		d = minf(1.0, d + 0.12)
	if mega:
		d = minf(1.0, d + 0.08)

	# jumlah jenis simbol
	var sym := 4
	if level >= 8:
		sym = 5
	if level >= 35:
		sym = 6
	if level >= 120:
		sym = 6 + rng.randi_range(0, 1)
	if boss and sym < 7:
		sym += 1

	# langkah
	var moves := int(round(lerpf(25.0, 15.0, d))) + rng.randi_range(-1, 2)
	if boss:
		moves -= 1
	moves = clampi(moves, 12, 30)
	if level == 1 or level == 2:
		moves = 20
	elif level == 3:
		moves = 22

	var budget := float(moves) * lerpf(1.7, 4.0, d)
	if boss:
		budget *= 1.12
	if level <= 3:
		budget = float(moves) * 1.4

	var types: Array = ["collect"]
	if level >= 6:
		types.append("ice")
	if level >= 10:
		types.append("chain")
	if level >= 14:
		types.append("special")

	var kinds: Array = []
	for i in sym:
		kinds.append(i)
	_shuffle(kinds, rng)

	var max_goals := 1 + int(d * 2.3)
	if level <= 3:
		max_goals = 1
	max_goals = mini(max_goals, 3)

	var goals: Array = []
	var used := {}
	var remaining := budget
	var ice_cells := 0
	var ice_layers := 1

	for gi in max_goals:
		var slots := max_goals - gi
		var share := remaining / float(slots)
		var choices: Array = []
		for t in types:
			if t == "collect" or not used.has(t):
				choices.append(t)
		var gtype: String = str(choices[rng.randi_range(0, choices.size() - 1)])
		if gi == 0 and level < 6:
			gtype = "collect"
		if gtype == "collect" and kinds.is_empty():
			gtype = "special" if types.has("special") else "chain"
			if not types.has(gtype):
				continue
		used[gtype] = true
		match gtype:
			"collect":
				var k: int = int(kinds.pop_back())
				var factor := 1.0 + float(sym - 4) * 0.1
				var amt := int(clampf(share / factor, 8.0, 70.0))
				goals.append({"type": "collect", "kind": k, "need": amt, "have": 0})
				remaining -= float(amt) * factor
			"ice":
				if d > 0.45 and rng.randf() < 0.6:
					ice_layers = 2
				ice_cells = int(clampf(share / (0.75 * float(ice_layers)), 4.0, 30.0))
				goals.append({"type": "ice", "need": 0, "have": 0})
				remaining -= float(ice_cells) * 0.75 * float(ice_layers)
			"chain":
				var clen := 5
				if d > 0.55 and rng.randf() < 0.5:
					clen = 6
				var cnt := int(clampf(share / (float(clen) * 1.7), 1.0, 4.0))
				goals.append({"type": "chain", "len": clen, "need": cnt, "have": 0})
				remaining -= float(cnt * clen) * 1.7
			"special":
				var cnt2 := int(clampf(share / 6.0, 1.0, 5.0))
				goals.append({"type": "special", "need": cnt2, "have": 0})
				remaining -= float(cnt2) * 6.0

	if goals.is_empty():
		goals.append({"type": "collect", "kind": 0, "need": 15, "have": 0})

	# letak es (simetris kiri-kanan)
	var ice: Array = []
	if ice_cells > 0:
		var taken := {}
		var count := 0
		var attempts := 0
		while count < ice_cells and attempts < 500:
			attempts += 1
			var c := rng.randi_range(0, COLS - 1)
			var r := rng.randi_range(1, ROWS - 1)
			var cs: Array = [c]
			var mc := COLS - 1 - c
			if mc != c:
				cs.append(mc)
			for cc in cs:
				var key := Vector2i(cc, r)
				if count < ice_cells and not taken.has(key):
					taken[key] = true
					ice.append([cc, r, ice_layers])
					count += 1
		for g in goals:
			if g["type"] == "ice":
				g["need"] = count * ice_layers

	var star2 := roundi(float(moves) * lerpf(45.0, 70.0, d) / 50.0) * 50
	var star3 := roundi(float(moves) * lerpf(80.0, 125.0, d) / 50.0) * 50

	return {
		"level": level,
		"symbols": sym,
		"moves": moves,
		"goals": goals,
		"ice": ice,
		"star2": star2,
		"star3": star3,
		"difficulty": d,
		"tier": int(clampf(d * 6.0, 0.0, 5.0)),
		"boss": boss,
		"bg": theme_of(level),
		"hue": hue_of(level),
	}
