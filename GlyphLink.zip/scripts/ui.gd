extends RefCounted
# Helper UI statis: tekstur, label, tombol, panel, popup.

const IMG := "res://assets/img/"
static var _cache: Dictionary = {}

const HUE_SHADER := """
shader_type canvas_item;
uniform float hue_shift = 0.0;
vec3 rgb2hsv(vec3 c) {
	vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
	vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
	vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
	float d = q.x - min(q.w, q.y);
	float e = 0.0000001;
	return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 hsv2rgb(vec3 c) {
	vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
	vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
	return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
void fragment() {
	vec4 t = texture(TEXTURE, UV);
	vec3 h = rgb2hsv(t.rgb);
	h.x = fract(h.x + hue_shift);
	COLOR = vec4(hsv2rgb(h), t.a);
}
"""


static func tex(n: String, ext: String = "png") -> Texture2D:
	var key := n + "." + ext
	if _cache.has(key):
		return _cache[key]
	var t = load(IMG + key)
	_cache[key] = t
	return t


static func fmt(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var cnt := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		cnt += 1
		if cnt % 3 == 0 and i > 0:
			out = "." + out
	return ("-" if n < 0 else "") + out


static func apply_hue(item: CanvasItem, hue: float) -> void:
	if hue <= 0.001:
		return
	var sh := Shader.new()
	sh.code = HUE_SHADER
	var mat := ShaderMaterial.new()
	mat.shader = sh
	mat.set_shader_parameter("hue_shift", hue)
	item.material = mat


static func label(text: String, font_size: int = 32, color: Color = Color.WHITE, outline: int = 6, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0.08, 0.04, 0.22, 0.95))
	l.add_theme_constant_override("outline_size", outline)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func tex_rect(n: String, pos: Vector2, rect_size: Vector2, ext: String = "png") -> TextureRect:
	var t := TextureRect.new()
	t.texture = tex(n, ext)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.position = pos
	t.size = rect_size
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


static func nine(n: String, margin: int = 40) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = tex(n)
	sb.texture_margin_left = margin
	sb.texture_margin_right = margin
	sb.texture_margin_top = margin
	sb.texture_margin_bottom = margin
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	return sb


static func panel(pos: Vector2, panel_size: Vector2, style: String = "panel_dark", margin: int = 36) -> Panel:
	var p := Panel.new()
	p.position = pos
	p.size = panel_size
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", nine(style, margin))
	return p


static func button(text: String, style: String = "btn_green", btn_size: Vector2 = Vector2(300, 96), font_size: int = 38) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.size = btn_size
	b.custom_minimum_size = btn_size
	b.pivot_offset = btn_size / 2.0
	var n := nine(style, 44)
	var h := nine(style, 44)
	h.modulate_color = Color(1.12, 1.12, 1.12)
	var p := nine(style, 44)
	p.modulate_color = Color(0.82, 0.82, 0.82)
	var dis := nine("btn_gray", 44)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", h)
	b.add_theme_stylebox_override("pressed", p)
	b.add_theme_stylebox_override("disabled", dis)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(0.8, 0.8, 0.9))
	b.add_theme_color_override("font_outline_color", Color(0.08, 0.04, 0.22, 0.95))
	b.add_theme_constant_override("outline_size", 7)
	b.button_down.connect(func(): b.scale = Vector2(0.95, 0.95))
	b.button_up.connect(func(): b.scale = Vector2.ONE)
	b.pressed.connect(func(): Sound.sfx("click"))
	return b


static func icon_button(icon_name: String, style: String = "btn_blue", btn_size: Vector2 = Vector2(80, 80)) -> Button:
	var b := button("", style, btn_size, 20)
	var inset := btn_size.x * 0.17
	b.add_child(tex_rect(icon_name, Vector2(inset, inset * 0.75), btn_size - Vector2(inset * 2.0, inset * 2.0)))
	return b


# Popup modal. Mengembalikan {"root": Control, "panel": Panel}. Isi diletakkan di "panel" (koordinat 0..ukuran).
static func make_popup(host: Control, popup_size: Vector2, title: String) -> Dictionary:
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	host.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.01, 0.12, 0.74)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var p := Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel", nine("panel", 44))
	p.anchor_left = 0.5
	p.anchor_right = 0.5
	p.anchor_top = 0.5
	p.anchor_bottom = 0.5
	p.offset_left = -popup_size.x / 2.0
	p.offset_right = popup_size.x / 2.0
	p.offset_top = -popup_size.y / 2.0
	p.offset_bottom = popup_size.y / 2.0
	p.pivot_offset = popup_size / 2.0
	root.add_child(p)
	if title != "":
		var head := panel(Vector2(popup_size.x / 2.0 - 230.0, -50.0), Vector2(460, 100), "popup_head", 40)
		p.add_child(head)
		var l := label(title, 44, Color.WHITE, 8)
		l.position = head.position + Vector2(0, -4)
		l.size = head.size
		p.add_child(l)
	p.scale = Vector2(0.7, 0.7)
	p.modulate.a = 0.0
	var tw := root.create_tween()
	tw.set_parallel(true)
	tw.tween_property(p, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(p, "modulate:a", 1.0, 0.18)
	return {"root": root, "panel": p}
