extends Node2D
# Satu simbol di papan. special: 0 biasa, 1 garis, 2 bom. dir: 0 vertikal, 1 horizontal, 2 diagonal \, 3 diagonal /

const UI = preload("res://scripts/ui.gd")

var kind: int = 0
var special: int = 0
var dir: int = 0
var col: int = 0
var row: int = 0
var spr: Sprite2D
var ov: Sprite2D
var halo: Sprite2D
var base_scale: float = 0.7
var _pulse: Tween = null
var rays: Sprite2D = null
var _spin: Tween = null


func setup(k: int, px: float) -> void:
	kind = k
	base_scale = px / 128.0
	halo = Sprite2D.new()
	halo.texture = UI.tex("glow")
	halo.visible = false
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	halo.material = mat
	add_child(halo)
	spr = Sprite2D.new()
	spr.texture = UI.tex("sym_%d" % k)
	spr.scale = Vector2(base_scale, base_scale)
	add_child(spr)
	ov = Sprite2D.new()
	ov.visible = false
	ov.scale = Vector2(base_scale, base_scale)
	add_child(ov)


func set_kind(k: int) -> void:
	if special == 3:
		return
	kind = k
	spr.texture = UI.tex("sym_%d" % k)


func make_special(sp: int, d: int) -> void:
	special = sp
	dir = d
	if sp == 1:
		ov.texture = UI.tex("fx_line_%d" % d)
	else:
		ov.texture = UI.tex("fx_bomb")
	ov.visible = true
	halo.visible = true
	halo.scale = Vector2(base_scale * 1.7, base_scale * 1.7)
	if sp == 1:
		halo.modulate = Color(1.0, 0.85, 0.4, 0.75)
	else:
		halo.modulate = Color(1.0, 0.5, 0.2, 0.8)
	if _pulse != null:
		_pulse.kill()
	_pulse = create_tween()
	_pulse.set_loops()
	_pulse.tween_property(ov, "scale", Vector2(base_scale * 1.1, base_scale * 1.1), 0.55)
	_pulse.tween_property(ov, "scale", Vector2(base_scale * 0.94, base_scale * 0.94), 0.55)
	spr.scale = Vector2(base_scale * 1.5, base_scale * 1.5)
	var tw := create_tween()
	tw.tween_property(spr, "scale", Vector2(base_scale, base_scale), 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func set_selected(on: bool) -> void:
	z_index = 5 if on else 1
	var s := base_scale * (1.14 if on else 1.0)
	spr.scale = Vector2(s, s)
	spr.modulate = Color(1.3, 1.3, 1.3) if on else Color.WHITE


# Matahari: netral (bisa disambung dengan simbol apa pun). Efek aktif saat hilang/hancur.
func make_sun() -> void:
	special = 3
	kind = -1
	dir = 0
	if _pulse != null:
		_pulse.kill()
		_pulse = null
	if _spin != null:
		_spin.kill()
		_spin = null
	ov.visible = false
	spr.texture = UI.tex("sym_sun")
	if rays == null:
		rays = Sprite2D.new()
		rays.texture = UI.tex("sun_rays")
		var rm := CanvasItemMaterial.new()
		rm.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		rays.material = rm
		add_child(rays)
		move_child(rays, 0)
	rays.scale = Vector2(base_scale * 0.8, base_scale * 0.8)
	halo.visible = true
	halo.scale = Vector2(base_scale * 1.9, base_scale * 1.9)
	halo.modulate = Color(1.0, 0.78, 0.3, 0.8)
	_spin = create_tween()
	_spin.set_loops()
	_spin.tween_property(rays, "rotation", TAU, 7.0).from(0.0)
	_pulse = create_tween()
	_pulse.set_loops()
	_pulse.tween_property(halo, "scale", Vector2(base_scale * 2.3, base_scale * 2.3), 0.7).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_pulse.tween_property(halo, "scale", Vector2(base_scale * 1.7, base_scale * 1.7), 0.7).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	spr.scale = Vector2(base_scale * 1.6, base_scale * 1.6)
	var tw := create_tween()
	tw.tween_property(spr, "scale", Vector2(base_scale, base_scale), 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
