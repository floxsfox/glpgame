extends "res://scripts/screen_base.gd"
# Layar permainan: HUD, papan, alat curang, popup menang/kalah/jeda.

const LevelGen = preload("res://scripts/level_gen.gd")
const BoardScript = preload("res://scripts/board.gd")
const BAR_X := 214.0
const BAR_W := 466.0
const DARK := Color(0.22, 0.13, 0.45)

var level: int = 1
var data: Dictionary = {}
var board
var moves_label: Label
var score_label: Label
var bar_fill: Panel
var hud_stars: Array = []
var goal_slots: Array = []
var toast_panel: Panel
var toast_label: Label
var toast_tween: Tween = null
var chain_label: Label
var tool_btns: Dictionary = {}
var popup: Dictionary = {}
var continues_used: int = 0
var finished: bool = false


func build() -> void:
	level = Game.current_level
	data = LevelGen.generate(level)
	bg.texture = UI.tex("bg_%d" % int(data["bg"]), "jpg")
	UI.apply_hue(bg, float(data["hue"]))
	_build_hud()
	_build_board()
	_build_tools()
	_refresh_hud()
	Sound.play_level_music(level)
	_show_intro()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and popup.is_empty() and not finished:
		_on_pause()


# ------------------------------------------------------------ HUD
func _build_hud() -> void:
	var pause_btn := UI.icon_button("ic_pause", "btn_blue", Vector2(80, 80))
	pause_btn.position = Vector2(24, 24)
	pause_btn.pressed.connect(_on_pause)
	content.add_child(pause_btn)

	var t1 := UI.label("LEVEL", 22, Color(0.88, 0.82, 1.0), 5)
	t1.position = Vector2(120, 8)
	t1.size = Vector2(350, 28)
	content.add_child(t1)
	var t2 := UI.label(str(level), 52, Color.WHITE, 8)
	t2.position = Vector2(120, 32)
	t2.size = Vector2(350, 62)
	content.add_child(t2)
	var tier: int = int(data["tier"])
	var ttxt: String = LevelGen.tier_name(tier)
	if data["boss"]:
		ttxt += " - BOSS"
	var t3 := UI.label(ttxt, 24, LevelGen.tier_color(tier), 5)
	t3.position = Vector2(120, 94)
	t3.size = Vector2(350, 28)
	content.add_child(t3)
	coin_pill(Vector2(500, 34), 200.0)

	content.add_child(UI.panel(Vector2(24, 128), Vector2(672, 190), "panel_dark", 36))
	var ml := UI.label("LANGKAH", 20, Color(0.8, 0.75, 1.0), 4)
	ml.position = Vector2(34, 138)
	ml.size = Vector2(170, 26)
	content.add_child(ml)
	moves_label = UI.label("0", 70, Color.WHITE, 9)
	moves_label.position = Vector2(34, 164)
	moves_label.size = Vector2(170, 80)
	content.add_child(moves_label)
	var sl := UI.label("SKOR", 20, Color(0.8, 0.75, 1.0), 4, HORIZONTAL_ALIGNMENT_LEFT)
	sl.position = Vector2(BAR_X, 138)
	sl.size = Vector2(200, 26)
	content.add_child(sl)
	score_label = UI.label("0", 44, Color(1, 0.95, 0.6), 7, HORIZONTAL_ALIGNMENT_LEFT)
	score_label.position = Vector2(BAR_X, 160)
	score_label.size = Vector2(BAR_W, 52)
	content.add_child(score_label)

	content.add_child(UI.panel(Vector2(BAR_X, 214), Vector2(BAR_W, 44), "bar_bg", 22))
	bar_fill = UI.panel(Vector2(BAR_X + 4, 218), Vector2(BAR_W - 8, 36), "bar_fill", 18)
	content.add_child(bar_fill)
	var s3 := float(data["star3"])
	var xs: Array = [BAR_X + BAR_W * 0.1, BAR_X + BAR_W * (float(data["star2"]) / s3), BAR_X + BAR_W - 14.0]
	for i in 3:
		var st := UI.tex_rect("star_off", Vector2(float(xs[i]) - 25.0, 210), Vector2(50, 50))
		content.add_child(st)
		hud_stars.append(st)

	var gl: Array = data["goals"]
	for i in gl.size():
		var g: Dictionary = gl[i]
		var x0 := 34.0 + float(i) * 220.0
		content.add_child(UI.tex_rect(LevelGen.goal_icon(g), Vector2(x0, 266), Vector2(48, 48)))
		var lb := UI.label("0/0", 28, Color.WHITE, 6, HORIZONTAL_ALIGNMENT_LEFT)
		lb.position = Vector2(x0 + 54, 264)
		lb.size = Vector2(140, 52)
		content.add_child(lb)
		var ck := UI.tex_rect("ic_check", Vector2(x0 + 24, 288), Vector2(30, 30))
		ck.visible = false
		content.add_child(ck)
		goal_slots.append({"label": lb, "check": ck})


func _build_board() -> void:
	content.add_child(UI.panel(Vector2(12, 328), Vector2(696, 792), "board_panel", 40))
	board = BoardScript.new()
	board.position = Vector2(24, 340)
	content.add_child(board)
	board.state_changed.connect(_refresh_hud)
	board.level_won.connect(_on_won)
	board.level_lost.connect(_on_lost)
	board.toast.connect(_on_board_toast)
	board.chain_changed.connect(_on_chain_changed)
	board.tool_mode_changed.connect(_on_tool_mode)

	chain_label = UI.label("", 42, Color(1, 0.92, 0.45), 9)
	chain_label.position = Vector2(24, 344)
	chain_label.size = Vector2(672, 56)
	chain_label.visible = false
	content.add_child(chain_label)

	toast_panel = UI.panel(Vector2(70, 430), Vector2(580, 72), "panel_dark", 30)
	toast_panel.visible = false
	content.add_child(toast_panel)
	toast_label = UI.label("", 26, Color.WHITE, 5)
	toast_label.size = Vector2(580, 72)
	toast_panel.add_child(toast_label)

	board.start(data)


func _build_tools() -> void:
	var defs := [
		["hammer", "Palu Dewa", "ic_hammer", "btn_orange"],
		["swap", "Tukar", "ic_swap", "btn_blue"],
		["destroy", "Hancurkan", "ic_destroy", "btn_red"],
	]
	for i in defs.size():
		var d: Array = defs[i]
		var b := UI.button("", str(d[3]), Vector2(200, 122))
		b.position = Vector2(36 + i * 224, 1136)
		content.add_child(b)
		b.add_child(UI.tex_rect(str(d[2]), Vector2(68, 2), Vector2(64, 64)))
		var nm := UI.label(str(d[1]), 21, Color.WHITE, 4)
		nm.position = Vector2(0, 62)
		nm.size = Vector2(200, 26)
		b.add_child(nm)
		b.add_child(UI.tex_rect("coin", Vector2(54, 87), Vector2(30, 30)))
		var pr := UI.label(str(BoardScript.PRICES[str(d[0])]), 24, Color(1, 0.95, 0.5), 4, HORIZONTAL_ALIGNMENT_LEFT)
		pr.position = Vector2(90, 85)
		pr.size = Vector2(90, 34)
		b.add_child(pr)
		b.pressed.connect(_on_tool.bind(str(d[0])))
		tool_btns[str(d[0])] = b


func _refresh_hud() -> void:
	if board == null or moves_label == null:
		return
	moves_label.text = str(board.moves_left)
	moves_label.add_theme_color_override("font_color", Color(1, 0.45, 0.4) if board.moves_left <= 3 else Color.WHITE)
	score_label.text = UI.fmt(board.score)
	var ratio := clampf(float(board.score) / float(data["star3"]), 0.0, 1.0)
	bar_fill.visible = ratio > 0.01
	bar_fill.size.x = maxf(36.0, (BAR_W - 8.0) * ratio)
	hud_stars[0].texture = UI.tex("star_on" if board.goals_done() else "star_off")
	hud_stars[1].texture = UI.tex("star_on" if board.score >= int(data["star2"]) else "star_off")
	hud_stars[2].texture = UI.tex("star_on" if board.score >= int(data["star3"]) else "star_off")
	for i in goal_slots.size():
		var g: Dictionary = board.goals[i]
		var need: int = int(g["need"])
		var have: int = mini(int(g["have"]), need)
		goal_slots[i]["label"].text = "%d/%d" % [have, need]
		goal_slots[i]["check"].visible = have >= need


func _show_toast(text: String, persistent: bool = false) -> void:
	toast_label.text = text
	toast_panel.visible = true
	toast_panel.modulate.a = 1.0
	if toast_tween != null:
		toast_tween.kill()
		toast_tween = null
	if persistent:
		return
	toast_tween = create_tween()
	toast_tween.tween_interval(1.7)
	toast_tween.tween_property(toast_panel, "modulate:a", 0.0, 0.4)
	toast_tween.tween_callback(func(): toast_panel.visible = false)


func _on_board_toast(msg: String) -> void:
	_show_toast(msg)


func _on_chain_changed(n: int) -> void:
	if n < 2:
		chain_label.visible = false
		return
	chain_label.visible = true
	var t := "x%d" % n
	if n >= 8:
		t += "  HANCURKAN SEMUA!"
	elif n >= 7:
		t += "  BOM!"
	elif n >= 5:
		t += "  GARIS!"
	chain_label.text = t


func _on_tool(tool_name: String) -> void:
	board.request_tool(tool_name)


func _on_tool_mode(mode: String) -> void:
	for k in tool_btns.keys():
		tool_btns[k].modulate = Color(1.3, 1.25, 0.65) if k == mode else Color.WHITE
	if mode == "hammer":
		_show_toast("PALU DEWA: ketuk simbol (hancur + 4 tetangga)", true)
	elif mode == "swap":
		_show_toast("TUKAR: pilih 2 simbol mana saja", true)
	else:
		if toast_panel.visible and toast_tween == null:
			toast_panel.visible = false


# ------------------------------------------------------------ popup util
func _close_popup() -> void:
	if popup.has("root"):
		popup["root"].queue_free()
	popup = {}


func _dlabel(parent: Control, text: String, font_size: int, pos: Vector2, lsize: Vector2, color: Color = DARK, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := UI.label(text, font_size, color, 0, align)
	l.position = pos
	l.size = lsize
	parent.add_child(l)
	return l


func _btn(parent: Control, text: String, style: String, pos: Vector2, bsize: Vector2, cb: Callable, fs: int = 38) -> Button:
	var b := UI.button(text, style, bsize, fs)
	b.position = pos
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _retry() -> void:
	Game.current_level = level
	Game.go("game")


func _next() -> void:
	Game.current_level = mini(level + 1, Game.MAX_LEVEL)
	Game.go("game")


func _to_menu() -> void:
	Game.go("menu")


func _to_levels() -> void:
	Game.go("levels")


# ------------------------------------------------------------ intro
func _show_intro() -> void:
	var gl: Array = data["goals"]
	var h := 540.0 + float(gl.size()) * 70.0
	popup = UI.make_popup(self, Vector2(600, h), "LEVEL %d" % level)
	var p: Panel = popup["panel"]
	var tier: int = int(data["tier"])
	var tt: String = LevelGen.tier_name(tier)
	if data["boss"]:
		tt += " - TANTANGAN BOSS!"
	_dlabel(p, tt, 32, Vector2(20, 66), Vector2(560, 44), LevelGen.tier_color(tier).darkened(0.45))
	_dlabel(p, "TARGET (%d langkah)" % int(data["moves"]), 26, Vector2(20, 116), Vector2(560, 36))
	var y := 158.0
	for g in gl:
		p.add_child(UI.tex_rect(LevelGen.goal_icon(g), Vector2(80, y), Vector2(56, 56)))
		_dlabel(p, LevelGen.goal_text(g), 30, Vector2(150, y), Vector2(400, 56), DARK, HORIZONTAL_ALIGNMENT_LEFT)
		y += 70.0
	var hl := _dlabel(p, LevelGen.hint(level), 22, Vector2(40, y + 6), Vector2(520, 130), Color(0.38, 0.3, 0.6))
	hl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var best := Game.stars_of(level)
	if best > 0:
		_dlabel(p, "Bintang terbaik: %d/3" % best, 22, Vector2(40, y + 130), Vector2(520, 30), Color(0.75, 0.45, 0.1))
	_btn(p, "MULAI!", "btn_green", Vector2(90, h - 120), Vector2(420, 96), _close_popup, 46)


# ------------------------------------------------------------ jeda
func _on_pause() -> void:
	if not popup.is_empty() or finished:
		return
	popup = UI.make_popup(self, Vector2(560, 700), "JEDA")
	var p: Panel = popup["panel"]
	_btn(p, "LANJUT", "btn_green", Vector2(70, 80), Vector2(420, 92), _close_popup, 42)
	_btn(p, "ULANGI", "btn_orange", Vector2(70, 190), Vector2(420, 92), _retry, 42)
	var mb := UI.icon_button("ic_music_on" if Game.music_on else "ic_music_off", "btn_purple", Vector2(110, 110))
	mb.position = Vector2(150, 306)
	p.add_child(mb)
	var sb := UI.icon_button("ic_sfx_on" if Game.sfx_on else "ic_sfx_off", "btn_purple", Vector2(110, 110))
	sb.position = Vector2(300, 306)
	p.add_child(sb)
	mb.pressed.connect(func():
		Sound.set_music(not Game.music_on)
		mb.get_child(0).texture = UI.tex("ic_music_on" if Game.music_on else "ic_music_off"))
	sb.pressed.connect(func():
		Sound.set_sfx(not Game.sfx_on)
		sb.get_child(0).texture = UI.tex("ic_sfx_on" if Game.sfx_on else "ic_sfx_off"))
	_btn(p, "PILIH LEVEL", "btn_blue", Vector2(70, 450), Vector2(420, 92), _to_levels, 38)
	_btn(p, "MENU UTAMA", "btn_red", Vector2(70, 560), Vector2(420, 92), _to_menu, 38)


# ------------------------------------------------------------ menang
func _on_won() -> void:
	finished = true
	var bonus_moves: int = board.moves_left
	var final_score: int = board.score + bonus_moves * 80
	var stars := 1
	if final_score >= int(data["star2"]):
		stars += 1
	if final_score >= int(data["star3"]):
		stars += 1
	var coins := 25 + stars * 10 + bonus_moves * 5
	if data["boss"]:
		coins += 50
	var new_best := final_score > Game.best_score(level)
	Game.complete_level(level, stars, final_score)
	Game.add_coins(coins)
	Sound.sfx("win")
	await get_tree().create_timer(0.7).timeout
	if not is_inside_tree():
		return
	_show_win(stars, final_score, bonus_moves, coins, new_best)


func _star_pop(s: TextureRect, i: int) -> void:
	s.texture = UI.tex("star_on")
	Sound.sfx("star", 1.0 + 0.18 * float(i))


func _show_win(stars: int, final_score: int, bonus_moves: int, coins: int, new_best: bool) -> void:
	_close_popup()
	popup = UI.make_popup(self, Vector2(620, 780), "SELESAI!")
	var p: Panel = popup["panel"]
	for i in 3:
		var yy := 70.0 - (18.0 if i == 1 else 0.0)
		var s := UI.tex_rect("star_off", Vector2(71.0 + float(i) * 164.0, yy), Vector2(150, 150))
		s.pivot_offset = Vector2(75, 75)
		p.add_child(s)
		if i < stars:
			s.modulate.a = 0.0
			s.scale = Vector2(2.4, 2.4)
			var tw := create_tween()
			tw.tween_interval(0.55 + float(i) * 0.45)
			tw.tween_callback(_star_pop.bind(s, i))
			tw.tween_property(s, "modulate:a", 1.0, 0.02)
			tw.tween_property(s, "scale", Vector2.ONE, 0.32).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_dlabel(p, "SKOR", 24, Vector2(20, 246), Vector2(580, 30))
	var sc := UI.label(UI.fmt(final_score), 58, Color(1, 0.8, 0.25), 8)
	sc.position = Vector2(20, 272)
	sc.size = Vector2(580, 70)
	p.add_child(sc)
	if new_best:
		_dlabel(p, "REKOR BARU!", 24, Vector2(20, 342), Vector2(580, 30), Color(0.85, 0.3, 0.4))
	_dlabel(p, "Sisa langkah: %d  (+%d skor)" % [bonus_moves, bonus_moves * 80], 24, Vector2(20, 376), Vector2(580, 30), Color(0.38, 0.3, 0.6))
	p.add_child(UI.tex_rect("coin", Vector2(200, 414), Vector2(60, 60)))
	var cl := UI.label("+%d" % coins, 46, Color(1, 0.85, 0.3), 8, HORIZONTAL_ALIGNMENT_LEFT)
	cl.position = Vector2(272, 414)
	cl.size = Vector2(200, 60)
	p.add_child(cl)
	_btn(p, "LANJUT", "btn_green", Vector2(90, 508), Vector2(440, 104), _next, 48)
	_btn(p, "ULANGI", "btn_orange", Vector2(90, 634), Vector2(212, 88), _retry, 32)
	_btn(p, "MENU", "btn_blue", Vector2(318, 634), Vector2(212, 88), _to_menu, 32)


# ------------------------------------------------------------ kalah
func _on_lost() -> void:
	finished = true
	Sound.sfx("lose")
	await get_tree().create_timer(0.6).timeout
	if not is_inside_tree():
		return
	_show_lose()


func _show_lose() -> void:
	_close_popup()
	popup = UI.make_popup(self, Vector2(600, 700), "GAGAL")
	var p: Panel = popup["panel"]
	_dlabel(p, "Langkah habis!", 34, Vector2(20, 66), Vector2(560, 46))
	_dlabel(p, "Target tersisa:", 24, Vector2(20, 116), Vector2(560, 32), Color(0.38, 0.3, 0.6))
	var y := 156.0
	for g in board.goals:
		var need: int = int(g["need"])
		var have: int = mini(int(g["have"]), need)
		if have >= need:
			continue
		p.add_child(UI.tex_rect(LevelGen.goal_icon(g), Vector2(120, y), Vector2(48, 48)))
		_dlabel(p, "%d/%d" % [have, need], 32, Vector2(180, y), Vector2(300, 48), DARK, HORIZONTAL_ALIGNMENT_LEFT)
		y += 56.0
	var cost := 150 * (continues_used + 1)
	var cb := _btn(p, "+5 LANGKAH", "btn_green", Vector2(80, 384), Vector2(440, 96), func(): pass, 40)
	cb.pressed.connect(_try_continue.bind(cb, cost))
	p.add_child(UI.tex_rect("coin", Vector2(214, 484), Vector2(44, 44)))
	var pl := UI.label(str(cost), 32, Color(1, 0.8, 0.25), 6, HORIZONTAL_ALIGNMENT_LEFT)
	pl.position = Vector2(266, 484)
	pl.size = Vector2(140, 44)
	p.add_child(pl)
	_btn(p, "ULANGI", "btn_orange", Vector2(80, 560), Vector2(212, 88), _retry, 32)
	_btn(p, "MENU", "btn_blue", Vector2(308, 560), Vector2(212, 88), _to_menu, 32)


func _try_continue(b: Button, cost: int) -> void:
	if Game.spend_coins(cost):
		continues_used += 1
		finished = false
		_close_popup()
		board.add_moves(5)
		Sound.sfx("coin")
	else:
		Sound.sfx("error")
		b.text = "Koin kurang!"
		var tw := create_tween()
		tw.tween_interval(1.1)
		tw.tween_callback(_reset_continue_text.bind(b))


func _reset_continue_text(b) -> void:
	if is_instance_valid(b):
		b.text = "+5 LANGKAH"
