# Glyph Link

Game puzzle hubungkan simbol (portrait) dibuat dengan Godot 4.3.

- 1.000.000 level dari generator (`scripts/level_gen.gd`)
- 5+ rantai = Garis, 7+ = Bom, 8+ = Hancurkan semua
- Palu Dewa, Tukar, Hancurkan (beli pakai koin)
- Bintang, skor, tantangan (koleksi, es, rantai, skill) dan tingkat kesulitan
- Musik: Lv 1-20 Royal Symphony, 21-40 Anthem of the Savannah, 41-50 Luina, 51-70 Lulunar, 71+ acak

Build web: lihat `export-web.yml` (GitHub Actions, Godot 4.3).
Buka `project.godot` di Godot 4.3+ untuk mengedit/menjalankan.
